from audioop import reverse
import pandas as pd
import numpy as np
import warnings; warnings.simplefilter('ignore')

def check_id(user_id):
    all_ids = [i for i in pd.read_csv('data/users_processed.csv')['user_id']]
    try:
        user_id = int(user_id)
        if user_id in all_ids:
            return user_id
    except: 
        return None

def find_recommendations(user_id):
    md = pd.read_csv('items_processed.csv')
    df = pd.read_csv('interactions_processed.csv')
    user_df = df[df['user_id']==user_id]

    if len(user_df) == 0:
        md = md[['item_id', 'title']]
        items_ids = df['item_id']
        pop_items = items_ids.value_counts().sort_values(ascending=False).index[:10]
        recs = pd.DataFrame(columns=['item_id', 'title'])

        for item in pop_items:
            title = md[md['item_id']==item]['title'].values[0]
            recs.loc[len(recs)] = [item, title]
        return recs
 
    else:
        item_id = np.random.choice(user_df['item_id'].values)
        item_genres = md[md['item_id']==item_id]
        viewed_ids = [i for i in item_genres['item_id'].values]

        for id in viewed_ids:
            md.drop(md[md['item_id']==id], axis=1)

        for value in item_genres['genres']:
            genres = value.split(',')
            all_dfs = []
            for genre in genres:
                genre = genre[1:] if genre[0]== " " else genre

                found = md[md['genres'].str.contains(genre)][['item_id', 'title']]
                all_dfs.append(found)
            
            all_df = pd.concat(all_dfs, axis=0)

            recs = all_df.iloc[np.random.permutation(len(all_df))][:10]
            return recs
